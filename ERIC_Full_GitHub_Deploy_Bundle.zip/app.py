
from flask import Flask, request, jsonify
from flask_cors import CORS
import openai

app = Flask(__name__)
CORS(app)

# Replace this with your actual OpenAI API key or use a local model
openai.api_key = "your-openai-api-key"

@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json()
    user_message = data.get('message', '')

    if not user_message:
        return jsonify({'reply': 'No message received.'}), 400

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are E.R.I.C., a tactical AI assistant."},
                {"role": "user", "content": user_message}
            ]
        )
        reply = response['choices'][0]['message']['content']
        return jsonify({'reply': reply})

    except Exception as e:
        return jsonify({'reply': 'Error connecting to AI.', 'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
